# FitForge Gym Workout App — Starter Prototype

This folder contains a responsive, interactive web prototype for FitForge.

## Run it
1. Extract the ZIP file.
2. Open `index.html` in a modern browser (Chrome recommended).
3. Choose a workout, start the rest timer, and mark a workout complete.
4. The prototype stores demo workout history in the browser's local storage on that device.

## What's included
- Responsive black + neon-lime UI for desktop and mobile browsers
- Three starter workout plans
- Workout detail modal
- 60-second rest timer
- Local workout history, weekly activity, and minutes trained
- Reset demo history button

## Important limitations
This is a front-end prototype, not a production service:
- No real user accounts or cloud database
- Data is local to the current browser/device and does not sync
- No subscriptions or payment processing
- Not yet packaged as a native Android app
- Workout content is general sample content, not individualized medical or training advice

## Suggested production build
- Website: Next.js + TypeScript
- Android: React Native + Expo
- Backend/authentication: Supabase with row-level security
- Payments: choose a compliant provider after deciding subscription rules
- Hosting: deploy the website and backend; submit the Android build to Google Play after testing and policy review

## Suggested next implementation steps
1. Set up the Next.js website and Expo app.
2. Move shared workout-plan data into a shared package.
3. Add Supabase authentication and tables for profiles, exercises, plans, sessions, and exercise logs.
4. Add privacy policy, terms, consent, account deletion, and secure authorization.
5. Add subscription entitlements and payment verification only after the free workout flow works.
6. Test with real users and qualified fitness reviewers before public release.
